package edu.iastate.cs2280.hw1;
/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */

public class Outage extends TownCell {
	
	/**
	 * Constructor that points to parent's constructor
	 * @param p
	 * @param r
	 * @param c
	 */
	public Outage(Town p, int r, int c) {
		super(p, r, c);

	}

	/**
	 * Returns the identity of the towncell (Outage)
	 */
	@Override
	public State who() {
		return State.OUTAGE;
	}

	/**
	 * Changes the identity of the towncell
	 */
	@Override
	public TownCell next(Town tNew) {
		toString();

		census(nCensus);
		nCensus[OUTAGE]--;
		TownCell updatedCell = new Empty(tNew, row, col);
		if(nCensus[CASUAL] >= 5) {
			updatedCell = new Streamer(tNew, row, col);
		}
		return updatedCell;
	}

	@Override
	public String toString() {
		String returnString = "O";
		return returnString;
	}
}