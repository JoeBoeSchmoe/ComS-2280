package edu.iastate.cs2280.hw1;

/**
 * 
 * @author Joseph Sheets
 *	Class: ComS 2280
 *	Instructor: Georgi Batinov 
 *	Last Edited: 9/21/24
 *
 */
public abstract class TownCell {

	protected Town plain;
	protected int row;
	protected int col;
	
	
	// constants to be used as indices.
	protected static final int RESELLER = 0;
	protected static final int EMPTY = 1;
	protected static final int CASUAL = 2;
	protected static final int OUTAGE = 3;
	protected static final int STREAMER = 4;
	
	public static final int NUM_CELL_TYPE = 5;
	
	//Use this static array to take census.
	public static final int[] nCensus = new int[NUM_CELL_TYPE];

	public TownCell(Town p, int r, int c) {
		plain = p;
		row = r;
		col = c;
	}
	
	/**
	 * Checks all neigborhood cell types in the neighborhood.
	 * Refer to homework pdf for neighbor definitions (all adjacent
	 * neighbors excluding the center cell).
	 * Use who() method to get who is present in the neighborhood
	 *  
	 * @param counts of all customers
	 */
	public void census(int nCensus[]) {
		// zero the counts of all customers
		nCensus[RESELLER] = 0; 
		nCensus[EMPTY] = 0; 
		nCensus[CASUAL] = 0; 
		nCensus[OUTAGE] = 0; 
		nCensus[STREAMER] = 0; 
		
		//System.out.println("Index: [" + row +"]["+ col + "]");
		//System.out.println(plain.getLength() + " " + plain.getWidth());
		int gridTopBounds = Math.max(0, row - 1);
		int gridBottomBounds = Math.min(plain.townGrid.length - 1, row + 1);
		int gridLeftBounds = Math.max(0, col - 1);
		int gridRightBounds = Math.min(plain.townGrid.length - 1, col + 1);

		/*System.out.println(); // Tested For IndexOutOfBounds Error
		
		System.out.println(gridTopBounds);
		System.out.println(gridBottomBounds);
		System.out.println(gridLeftBounds);
		System.out.println(gridRightBounds);

		System.out.println("Top Bounds: " + gridTopBounds + " Bottom Bounds: " + gridBottomBounds);
		System.out.println("Left Bounds: " + gridLeftBounds + " Right Bounds: " + gridRightBounds);*/
		
		for(int i = gridBottomBounds; i >= gridTopBounds; i--) {
			for(int j = gridRightBounds; j >= gridLeftBounds; j--) {
				if(plain.townGrid[i][j].who() == State.RESELLER) {
					nCensus[RESELLER]++;
				}
				else if(plain.townGrid[i][j].who() == State.EMPTY) {
					nCensus[EMPTY]++;
				}
				else if(plain.townGrid[i][j].who() == State.CASUAL) {
					nCensus[CASUAL]++;
				}
				else if(plain.townGrid[i][j].who() == State.OUTAGE) {
					nCensus[OUTAGE]++;
				}
				else if(plain.townGrid[i][j].who() == State.STREAMER) {
					nCensus[STREAMER]++;
				}
			}
		}
		//System.out.println("Reseller: " + nCensus[RESELLER] + " Empty: " + nCensus[EMPTY] + " Casual: " + nCensus[CASUAL] + " Outage: " + nCensus[OUTAGE] + " Streamer: " + nCensus[STREAMER]);

	}

	/**
	 * Gets the identity of the cell.
	 * 
	 * @return State
	 */
	public abstract State who();

	/**
	 * Determines the cell type in the next cycle.
	 * 
	 * @param tNew: town of the next cycle
	 * @return TownCell
	 */
	public abstract TownCell next(Town tNew);
	
	@Override
	public abstract String toString();
		
}
