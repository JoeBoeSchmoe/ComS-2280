package edu.iastate.cs2280.hw1;

/**
 * 
 *	@author: Joseph Sheets
 *	Last Edited: 9/21/24
 * 
 */

public class Empty extends TownCell {
	
	/**
	 * Constructor that points to parent's constructor
	 * @param p
	 * @param r
	 * @param c
	 */
	public Empty(Town p, int r, int c) {
		super(p, r, c);
	}

	/**
	 * Returns the identity of the towncell (Empty)
	 */
	@Override
	public State who() {
		return State.EMPTY;
	}

	/**
	 * Changes the identity of the towncell
	 */
	@Override
	public TownCell next(Town tNew) {
		census(nCensus);
		nCensus[EMPTY]--;
		TownCell updatedCell = new Casual(tNew, row, col);
		if(nCensus[EMPTY] + nCensus[OUTAGE] <= 1) {
			updatedCell = new Reseller(tNew, row, col);
		}
		return updatedCell;
	}

	@Override
	public String toString() {
		String returnString = "E";
		return returnString;
	}

}
