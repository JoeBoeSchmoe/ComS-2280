package edu.iastate.cs2280.hw1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;


/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */
public class Town {
	
	private int length, width;  //Row and col (first and second indices)
	public TownCell[][] townGrid;
	
	/**
	 * Constructor to be used when user wants to generate grid randomly, with the given seed.
	 * This constructor does not populate each cell of the grid (but should assign a 2D array to it).
	 * @param length
	 * @param width
	 */
	public Town(int length, int width) {
		this.length = length;
		this.width = width;
		if(length < 1 || width < 1) {
			System.out.println("Grid can not exist with these parameters");
		}
		townGrid = new TownCell[length][width];
		
	}
	
	/**
	 * 
	 * @param length
	 * @param width
	 */
	public Town(int length, int width, int ranSeed) {
		this.length = length;
		this.width = width;
		if(length < 1 || width < 1) {
			System.out.println("Grid can not exist with these parameters");
		}
		else {
			randomInit(ranSeed);
		}
	}
	/**
	 * Constructor to be used when user wants to populate grid based on a file.
	 * Please see that it simple throws FileNotFoundException exception instead of catching it.
	 * Ensure that you close any resources (like file or scanner) which is opened in this function.
	 * @param inputFileName
	 * @throws FileNotFoundException
	 */
	public Town(String inputFileName) throws FileNotFoundException {
		String filePath = inputFileName;
		File myFile = new File(filePath);
		
		try {
			Scanner fileScanner = new Scanner(myFile);
			this.length = fileScanner.nextInt();
			this.width = fileScanner.nextInt();
			if(length < 1 || width < 1) {
				System.out.println("Grid can not exist with these parameters");
			}
			townGrid = new TownCell[length][width];
			for(int i = 0; i < length; i++) {
				for(int j = 0; j < width; j++) {
					String cellChar = fileScanner.next();
					TownCell newCell;
					if(cellChar.equals("R")) {
						newCell = new Reseller(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(cellChar.equals("E")) {
						newCell = new Empty(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(cellChar.equals("C")) {
						newCell = new Casual(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(cellChar.equals("O")) {
						newCell = new Outage(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(cellChar.equals("S")) {
						newCell = new Streamer(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(cellChar != "R" && cellChar != "E" && cellChar != "C" && cellChar != "O" && cellChar != "S") {
						System.out.println("Unknown Element Detected In File: " + "(" + cellChar + ")" + " Detected At Grid Index[" + i + "][" + j + "]");
					}
				}
			}
		}
		catch(NullPointerException firstExpected) {
			System.out.println("NullPointerException (Detected In Town File Constructor)");
		}
		catch(FileNotFoundException secondExpected) {
			System.out.println("FileNotFoundException (Detected In Town)");

		}
		catch(Exception allOther) {
			System.out.println("Unknown Error (Detected in Town)");
		}
		
	}
	
	/**
	 * Returns width of the grid.
	 * @return
	 */
	public int getWidth() {
		return width;
	}
	
	/**
	 * Returns length of the grid.
	 * @return
	 */
	public int getLength() {
		return length;
	}

	
	/**
	 * Initialize the grid by randomly assigning cell with one of the following class object:
	 * Casual, Empty, Outage, Reseller OR Streamer
	 */
	public void randomInit(int ranSeed) {
		townGrid = new TownCell[length][width];
		Random randomGen = new Random(ranSeed);
		try {
			for(int i = 0; i < length; i++) {
				for(int j = 0; j < width; j++) {
					int randomCellNum = randomGen.nextInt(5);
					TownCell newCell;
					if(randomCellNum == 0) {
						newCell = new Reseller(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(randomCellNum == 1) {
						newCell = new Empty(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(randomCellNum == 2) {
						newCell = new Casual(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(randomCellNum == 3) {
						newCell = new Outage(this, i, j);
						townGrid[i][j] = newCell;
					}
					else if(randomCellNum == 4) {
						newCell = new Streamer(this, i, j);
						townGrid[i][j] = newCell;
					}
				}
			}
		}
		catch(NullPointerException firstExpected) {
			System.out.println("NullPointerException (Detected In Town Random Constructor)");
		}
	}
	
	/**
	 * Output the town grid. For each square, output the first letter of the cell type.
	 * Each letter should be separated either by a single space or a tab.
	 * And each row should be in a new line. There should not be any extra line between 
	 * the rows.
	 */
	@Override
	public String toString() {
		String myGridString = "";
		try {
			for(int i = 0; i < length; i++) {
				for(int j = 0; j < width; j++) {
					System.out.print(townGrid[i][j].toString() + " ");
				}
				System.out.println();
			}
		}
		catch(NullPointerException firstExpected) {
			System.out.println("NullPointerException (Detected In ToString Method In Town Class)");
		}
		catch(Exception allOther) {
			System.out.println("Unknown Error (Detected In ToString Method In Town Class)");
		}
		
		return myGridString;
	}
}
