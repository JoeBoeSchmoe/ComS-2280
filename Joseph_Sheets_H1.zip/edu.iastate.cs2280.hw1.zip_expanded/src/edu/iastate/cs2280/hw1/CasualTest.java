package edu.iastate.cs2280.hw1;

/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */

public class CasualTest {

	public static void main(String[] args) {
		Town testTown = new Town(3,3,4);
		testTown.toString();
		//R Located At (0,0)
		testTown.townGrid[0][0] = testTown.townGrid[0][0].next(testTown); // Expected C --> R
		System.out.println();
		testTown.toString();

	}

}
