package edu.iastate.cs2280.hw1;
/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */

public class Streamer extends TownCell {
	
	/**
	 * Constructor that points to parent's constructor
	 * @param p
	 * @param r
	 * @param c
	 */
	public Streamer(Town p, int r, int c) {
		super(p, r, c);
	}

	/**
	 * Returns the identity of the towncell (Streamer)
	 */
	@Override
	public State who() {
		return State.STREAMER;
	}

	/**
	 * Changes the identity of the towncell
	 */
	@Override
	public TownCell next(Town tNew) {
		census(nCensus);
		nCensus[STREAMER]--;
		TownCell updatedCell = new Streamer(tNew, row, col);
		if(nCensus[EMPTY] + nCensus[OUTAGE] <= 1) {
			updatedCell = new Reseller(tNew, row, col);
		}
		else if(nCensus[RESELLER] >= 1) {
			updatedCell = new Outage(tNew, row, col);
		}
		else if(nCensus[OUTAGE] >= 1) {
			updatedCell = new Empty(tNew, row, col);
		}
		else if(nCensus[CASUAL] >= 5) {
			return updatedCell;
		}
		return updatedCell;
	}

	@Override
	public String toString() {
		String returnString = "S";
		return returnString;
	}
}
