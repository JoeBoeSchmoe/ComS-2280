package edu.iastate.cs2280.hw1;

/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */

public class TownCellTest {

	public static void main(String[] args) {
		Town testTown = new Town(3,3,5);
		testTown.toString();
		
		testTown.townGrid[0][0].next(testTown);
		System.out.println();
		testTown.toString();

		System.out.println(testTown.townGrid[0][0].nCensus[0]); // Expected: No Reseller Neighbors
		System.out.println(testTown.townGrid[0][0].nCensus[1]); // Expected: 1 Empty
		System.out.println(testTown.townGrid[0][0].nCensus[2]); // Expected: 1 Casual
		System.out.println(testTown.townGrid[0][0].nCensus[3]); // Expected: No Outage
		System.out.println(testTown.townGrid[0][0].nCensus[4]); // Expected: 1 Streamer
		

	}

}
