package edu.iastate.cs2280.hw1;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author Joseph Sheets
 * Last Edited: 9/21/24
 *
 * The ISPBusiness class performs simulation over a grid 
 * plain with cells occupied by different TownCell types.
 *
 */
public class ISPBusiness {
	public static int totalRegisteredCasuals;
	
	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * @param tOld: old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld) {
		Town tNew = new Town(tOld.getLength(), tOld.getWidth());
		for(int i = 0; i < tNew.getLength(); i++) {
			for(int j = 0; j < tNew.getWidth(); j++) {
				tNew.townGrid[i][j] = tOld.townGrid[i][j].next(tNew);
			}
		}
		return tNew;
	}
	
	/**
	 * Returns the profit for the current state in the town grid.
	 * @param town
	 * @return
	 */
	public static int getProfit(Town town) {
		int MonthlyRegisteredCasuals = 0;
		for(int i = 0; i < town.getLength(); i++) {
			for(int j = 0; j < town.getWidth(); j++) {
				if(town.townGrid[i][j].who() == State.CASUAL) {
					totalRegisteredCasuals++;
					MonthlyRegisteredCasuals++;
				}
			}
		}
		return (MonthlyRegisteredCasuals * 1);
	}
	

	/**
	 *  Main method. Interact with the user and ask if user wants to specify elements of grid
	 *  via an input file (option: 1) or wants to generate it randomly (option: 2).
	 *  
	 *  Depending on the user choice, create the Town object using respective constructor and
	 *  if user choice is to populate it randomly, then populate the grid here.
	 *  
	 *  Finally: For 12 billing cycle calculate the profit and update town object (for each cycle).
	 *  Print the final profit in terms of %. You should print the profit percentage
	 *  with two digits after the decimal point:  Example if profit is 35.5600004, your output
	 *  should be:
	 *
	 *	35.56%
	 *  
	 * Note that this method does not throw any exception, so you need to handle all the exceptions
	 * in it.
	 * 
	 * @param args
	 * 
	 */
	public static void main(String []args) {
		System.out.println("How to populate grid (type 1 or 2): 1: from a file. 2: randomly with seed”");
		Scanner myInputScanner = new Scanner(System.in);
		int howToPopulate = 1;
		Town joeTown;
		Town bobTown;
		final int numMonthsInYear = 12;
		try {
			howToPopulate = myInputScanner.nextInt();
			myInputScanner.nextLine(); // To Consume Dangling \n
		}
		catch(InputMismatchException firstExpected) {
			System.out.println("InputMismatchException Detected in class ISPBusiness");
			System.out.println("Wrong Input! Default Value Assigned (1)");
		}
		catch(IllegalArgumentException secondExpected) {
			System.out.println("IllegalArgumentException Detected in class ISPBusiness");
			System.out.println("Wrong Input! Default Value Assigned (1)");
		}
		catch(Exception allOther) {
			System.out.println("Unknown Exception Detected In Class ISPBusiness");
		}

		if(howToPopulate != 1 && howToPopulate != 2) {
			System.out.println("Wrong Input! Default Value Assigned (1)");
			howToPopulate = 1;
		}
		if(howToPopulate == 1) {
			try {
				System.out.print("Please enter file path: ");
				String filePath = myInputScanner.nextLine();
				//String filePath = "C:\\Users\\josep\\OneDrive\\Desktop\\CompS 2280\\edu.iastate.cs2280.hw1.zip_expanded\\src\\edu\\iastate\\cs2280\\hw1\\ISP4x4.txt";
				File myFile = new File(filePath);
				joeTown = new Town(filePath);
				
				System.out.println("\n---Start---");
				joeTown.toString();
				System.out.println("Profit: " + getProfit(joeTown));
				

				for(int i = 0; i < numMonthsInYear - 1; i++) {
					Town tNew = new Town(joeTown.getLength(), joeTown.getWidth());
					tNew = updatePlain(joeTown);
					System.out.println("\n---Iteration" + (i + 1) + "---");
					tNew.toString();
					System.out.println("Profit: " + getProfit(tNew));
					bobTown = tNew;
				}
				System.out.println("Total Profit For 12 Months: $" + totalRegisteredCasuals * 1);
				DecimalFormat df = new DecimalFormat("#.00");
				System.out.println("Profit Utilization: " + df.format((100 *(totalRegisteredCasuals * 1) / (12.0 * (joeTown.getLength() * joeTown.getWidth())))) + "%");
			}
			catch(FileNotFoundException firstExpected) {
				System.out.println("FileNotFoundException Detected In ISPBusiness");
			}
			catch(Exception allOther) {
				System.out.println("Unknown Exception Detected In Class ISPBusiness");
			}
		}
		// Input Length And Width Version 
		else if(howToPopulate == 2) {

			System.out.println("Provide rows, cols and seed integer separated by spaces: ");
			String myInputs = "" + myInputScanner.nextLine();
			int[] parameters = new int[3];
			Scanner tempScan = new Scanner(myInputs);
			
			try {
				int index = 0;
				while(tempScan.hasNext()) {
					parameters[index] = tempScan.nextInt();
					index++;
				}
					
				if(parameters[0] < 1 || parameters[1] < 1) { // Looks For Impossible Parameters And Sets To Default If Detected
					System.out.println("Grid can not exist with these parameters! Default vlaues assigned (3,3 3)");
					parameters[0] = 3;
					parameters[1] = 3;
					parameters[2] = 3;
				}
					
				bobTown = new Town(parameters[0], parameters[1], parameters[2]);
				System.out.println("\n---Start---");
				bobTown.toString();
				System.out.println("Profit: " + getProfit(bobTown));
				

				for(int i = 0; i < numMonthsInYear - 1; i++) {
					Town tNew = new Town(parameters[0], parameters[1]);
					tNew = updatePlain(bobTown);
					System.out.println("\n---Iteration" + (i + 1) + "---");
					tNew.toString();
					System.out.println("Profit: " + getProfit(tNew));
					bobTown = tNew;
				}
				System.out.println("Total Profit For 12 Months: $" + totalRegisteredCasuals * 1);
				DecimalFormat df = new DecimalFormat("#.00");
				System.out.println("Profit Utilization: " + df.format((100 *(totalRegisteredCasuals * 1) / (12.0 * (parameters[0] * parameters[1])))) + "%");
				//System.out.println(parameters[0] + " " + parameters[1]);
				//Town tNew = new Town(parameters[0], parameters[1]);
				//tNew = updatePlain(bobTown);
				//System.out.println("\n---Iteration 1---");
			//	tNew.toString();
				//System.out.println(tNew.townGrid[0][3].toString()); // Was Testing Updating Of Cells
			}
			catch(InputMismatchException firstExpected) {
				System.out.println("InputMismatchException Detected In ISPBusiness");
			}
			catch(ArrayIndexOutOfBoundsException secondExpected) {
				System.out.println("ArrayIndexOutOfBoundsException Detected In ISPBusiness");
			}
			catch(NullPointerException thirdExpected) {
				System.out.println("NullPointerException Detected In ISPBusiness");
			}
			catch(Exception allOther) {
				System.out.println("Unknown Exception Detected In Class ISPBusiness");
			}
		}
	}
	
}
