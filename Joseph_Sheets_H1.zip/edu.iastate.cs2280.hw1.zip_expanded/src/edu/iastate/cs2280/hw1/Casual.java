package edu.iastate.cs2280.hw1;

/**
 * 
 *	@author: Joseph Sheets
 *	Last Edited: 9/21/24
 * 
 */

public class Casual extends TownCell {
	
	/**
	 * Constructor that points to parent's constructor
	 * @param p
	 * @param r
	 * @param c
	 */
	public Casual(Town p, int r, int c) {
		super(p, r, c);
	}

	/**
	 * Returns the identity of the towncell (Casual)
	 */
	@Override
	public State who() {
		return State.CASUAL;
	}

	/**
	 * Changes the identity of the towncell
	 */
	@Override
	public TownCell next(Town tNew) {
		census(nCensus);
		nCensus[CASUAL]--;
		TownCell updatedCell = new Casual(tNew, row, col);
		if(nCensus[EMPTY] + nCensus[OUTAGE] <= 1) {
			updatedCell = new Reseller(tNew, row, col);
		}
		else if(nCensus[RESELLER] >= 1) {
			updatedCell = new Outage(tNew, row, col);
		}
		else if(nCensus[STREAMER] >= 1) {
			updatedCell = new Streamer(tNew, row, col);
		}
		else if(nCensus[CASUAL] >= 5) {
			updatedCell = new Streamer(tNew, row, col);
		}
		return updatedCell;
	}

	@Override
	public String toString() {
		String returnString = "C";
		return returnString;
	}
}