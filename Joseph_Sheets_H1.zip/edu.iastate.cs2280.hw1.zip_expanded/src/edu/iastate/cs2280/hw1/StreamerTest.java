package edu.iastate.cs2280.hw1;

/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */

public class StreamerTest {

	public static void main(String[] args) {
		Town testTown = new Town(3,3,5);
		testTown.toString();
		//R Located At (0,2)
		testTown.townGrid[0][2] = testTown.townGrid[0][2].next(testTown); // Expected S --> R
		System.out.println();
		testTown.toString();
	}

}
