package edu.iastate.cs2280.hw1;

/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */
import java.io.File;
import java.io.FileNotFoundException;

public class TownTest {

	public static void main(String[] args) throws FileNotFoundException {
		String filePath = "C:\\Users\\josep\\OneDrive\\Desktop\\CompS 2280\\edu.iastate.cs2280.hw1.zip_expanded\\src\\edu\\iastate\\cs2280\\hw1\\ISP4x4.txt";
		File myFile = new File(filePath);
		Town testTown = new Town(filePath);

		testTown.toString();
		
		Town otherTown = new Town(4,4,5);
		System.out.println();
		otherTown.toString();
	}

}
