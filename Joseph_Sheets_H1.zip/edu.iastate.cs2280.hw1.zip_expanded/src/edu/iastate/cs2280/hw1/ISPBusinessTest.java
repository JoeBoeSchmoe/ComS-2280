package edu.iastate.cs2280.hw1;

/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */

public class ISPBusinessTest extends ISPBusiness{

	public static void main(String[] args) {
		Town testTown = new Town(3,3,4);
		testTown.toString();
		//R Located At (2,0)
		System.out.println("Profit: " + getProfit(testTown));

		Town newTown = new Town(3,3);
		newTown = updatePlain(testTown);
		System.out.println();
		newTown.toString();
		
		System.out.println("Profit: " + getProfit(newTown));
	}

}
