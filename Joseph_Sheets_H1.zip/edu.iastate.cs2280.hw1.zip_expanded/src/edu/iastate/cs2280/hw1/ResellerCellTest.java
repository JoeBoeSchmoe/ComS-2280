package edu.iastate.cs2280.hw1;

/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ResellerCellTest {

	public static void main(String[] args) {
		Town testTown = new Town(3,3,4);
		testTown.toString();
		//R Located At (1,2)
		testTown.townGrid[1][2] = testTown.townGrid[1][2].next(testTown); // Expected R --> E
		System.out.println();
		testTown.toString();
	}
	
	
}
