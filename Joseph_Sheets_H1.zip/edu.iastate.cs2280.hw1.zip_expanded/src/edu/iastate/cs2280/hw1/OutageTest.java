package edu.iastate.cs2280.hw1;

/**
 * 
 * @author: Joseph Sheets
 * Last Edited: 9/21/24
 *  
 */

public class OutageTest {

	public static void main(String[] args) {
		Town testTown = new Town(3,3,4);
		testTown.toString();
		//R Located At (0,2)
		testTown.townGrid[0][2] = testTown.townGrid[0][2].next(testTown); // Expected O --> E
		System.out.println();
		testTown.toString();
	}

}
