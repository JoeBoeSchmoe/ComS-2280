package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;


/**
 *  
 * @author
 *
 */

/**
 * 
 * This class implements the version of the quicksort algorithm presented in the lecture.   
 *
 */

public class QuickSorter extends AbstractSorter
{
	
	// Other private instance variables if you need ... 
		
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *   
	 * @param pts   input array of integers
	 */
	public QuickSorter(Point[] pts)
	{
		super(pts);
		super.algorithm = "QuickSort";

	}
		

	/**
	 * Carry out quicksort on the array points[] of the AbstractSorter class.  
	 * 
	 */
	@Override 
	public void sort()
	{
		quickSortRec(0, points.length-1);
	}
	
	
	/**
	 * Operates on the subarray of points[] with indices between first and last. 
	 * 
	 * @param first  starting index of the subarray
	 * @param last   ending index of the subarray
	 */
	private void quickSortRec(int lowIndex, int highIndex)
	{
		if(lowIndex >= highIndex) {
			return;
		}
		Point thePivot = points[highIndex];
		
		int leftPointer = lowIndex;
		int rightPointer = highIndex;
		
		while(leftPointer < rightPointer) {
			
			while(points[leftPointer].compareTo(thePivot) == -1 && leftPointer < rightPointer) {
				leftPointer++;
			}
			
			while(points[rightPointer].compareTo(thePivot) >= 0 && leftPointer < rightPointer) {
				rightPointer--;
			}
			
			swap(leftPointer, rightPointer);
		}
		
		swap(leftPointer, highIndex);
		quickSortRec(lowIndex, leftPointer-1);
		quickSortRec(leftPointer+1, highIndex);
	}

	// Other private methods if needed ...
}
