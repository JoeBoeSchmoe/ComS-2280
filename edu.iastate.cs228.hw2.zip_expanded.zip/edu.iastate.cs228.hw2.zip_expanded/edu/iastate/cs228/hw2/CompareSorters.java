package edu.iastate.cs228.hw2;

import java.io.File;

/**
 *  
 * @author
 *
 */

/**
 * 
 * This class executes four sorting algorithms: selection sort, insertion sort, mergesort, and
 * quicksort, over randomly generated integers as well integers from a file input. It compares the 
 * execution times of these algorithms on the same input. 
 *
 */

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Random; 


public class CompareSorters 
{
	/**
	 * Repeatedly take integer sequences either randomly generated or read from files. 
	 * Use them as coordinates to construct points.  Scan these points with respect to their 
	 * median coordinate point four times, each time using a different sorting algorithm.  
	 * 
	 * @param args
	 **/
	public static void main(String[] args) 
	{	
		
		Scanner myScanner = new Scanner(System.in);
		String filePath = null;
		int inputAnswer = 5;
		int testTrials;
		
		try {
			System.out.println("--------------------------------------------------------\nType [1] To Generate Random Points To "
					+ "Sort\nType [2] To Input A File Path\nType [3] For Both\nType [4] To Quit\n--------------------------------------------------------");
			inputAnswer = myScanner.nextInt();
			
			while(inputAnswer != 1 && inputAnswer != 2 && inputAnswer != 3 && inputAnswer != 4) {
				System.out.print("Wrong Input! Try Again! ");
				inputAnswer = myScanner.nextInt();
				
			}
			while(inputAnswer != 4) {
				if(inputAnswer == 1) {
					int numPoints;
					Random randomGen = new Random();
					System.out.println("Type The Number Of Points You Would Like");
					numPoints = myScanner.nextInt();
					Point[] randomGenerated = generateRandomPoints(numPoints, randomGen);
					
					System.out.print ("Input Number Of Test Trials ");
					testTrials = myScanner.nextInt();
					for(int i = 1; i <= testTrials; i++) {
						PointScanner selectionSorter = new PointScanner(randomGenerated, Algorithm.SelectionSort);
						PointScanner insertionSorter = new PointScanner(randomGenerated, Algorithm.InsertionSort);
						PointScanner mergeSorter = new PointScanner(randomGenerated, Algorithm.MergeSort);
						PointScanner quickSorter = new PointScanner(randomGenerated, Algorithm.QuickSort);

						System.out.println("\n[Test Trial #" + i + "] [Random Input] \nAlgorithm			Size			Time (ns)\n--------------------------------------------------------");	
					
						selectionSorter.scan();
						System.out.println(selectionSorter.stats());
						insertionSorter.scan();
						System.out.println(insertionSorter.stats());
						mergeSorter.scan();
						System.out.println(mergeSorter.stats());
						quickSorter.scan();
						System.out.println(quickSorter.stats() + "\n");
						if(i == testTrials) {
							quickSorter.RandomWriteMCPToFile();
						}
					}
				}
				
				if(inputAnswer == 2) {
					System.out.print("\nPlease Enter A File Path ");
					filePath = myScanner.next();
					
					System.out.print ("Input Number Of Test Trials ");
					testTrials = myScanner.nextInt();
					for(int i = 1; i <= testTrials; i++) {
						PointScanner selectionSorter = new PointScanner(filePath, Algorithm.SelectionSort);
						PointScanner insertionSorter = new PointScanner(filePath, Algorithm.InsertionSort);
						PointScanner mergeSorter = new PointScanner(filePath, Algorithm.MergeSort);
						PointScanner quickSorter = new PointScanner(filePath, Algorithm.QuickSort);
						System.out.println("\n[Test Trial #" + i + "] [File Input] \nAlgorithm			Size			Time (ns)\n--------------------------------------------------------");	
						selectionSorter.scan();
						System.out.println(selectionSorter.stats());
						insertionSorter.scan();
						System.out.println(insertionSorter.stats());
						mergeSorter.scan();
						System.out.println(mergeSorter.stats());
						quickSorter.scan();
						System.out.println(quickSorter.stats() + "\n");
						if(i == testTrials) {
							quickSorter.FileWriteMCPToFile();
						}
					}
				}
				if(inputAnswer == 3) {
					System.out.print ("Input Number Of Test Trials ");
					testTrials = myScanner.nextInt();
					
					int numPoints;
					Random randomGen = new Random();
					System.out.println("Type The Number Of Points You Would Like");
					numPoints = myScanner.nextInt();
					Point[] randomGenerated = generateRandomPoints(numPoints, randomGen);
				
					for(int i = 1; i <= testTrials; i++) {
						PointScanner selectionSorter = new PointScanner(randomGenerated, Algorithm.SelectionSort);
						PointScanner insertionSorter = new PointScanner(randomGenerated, Algorithm.InsertionSort);
						PointScanner mergeSorter = new PointScanner(randomGenerated, Algorithm.MergeSort);
						PointScanner quickSorter = new PointScanner(randomGenerated, Algorithm.QuickSort);

						System.out.println("\n[Test Trial #" + i + "] [Random Input] \nAlgorithm			Size			Time (ns)\n--------------------------------------------------------");	
					
						selectionSorter.scan();
						System.out.println(selectionSorter.stats());
						insertionSorter.scan();
						System.out.println(insertionSorter.stats());
						mergeSorter.scan();
						System.out.println(mergeSorter.stats());
						quickSorter.scan();
						System.out.println(quickSorter.stats() + "\n");
						if(i == testTrials) {
							quickSorter.RandomWriteMCPToFile();
						}
					}
					
					System.out.print("\nPlease Enter A File Path ");
					filePath = myScanner.next();
					for(int i = 1; i <= testTrials; i++) {
						PointScanner selectionSorter = new PointScanner(filePath, Algorithm.SelectionSort);
						PointScanner insertionSorter = new PointScanner(filePath, Algorithm.InsertionSort);
						PointScanner mergeSorter = new PointScanner(filePath, Algorithm.MergeSort);
						PointScanner quickSorter = new PointScanner(filePath, Algorithm.QuickSort);
						System.out.println("\n[Test Trial #" + i + "] [File Input] \nAlgorithm			Size			Time (ns)\n--------------------------------------------------------");	
						selectionSorter.scan();
						System.out.println(selectionSorter.stats());
						insertionSorter.scan();
						System.out.println(insertionSorter.stats());
						mergeSorter.scan();
						System.out.println(mergeSorter.stats());
						quickSorter.scan();
						System.out.println(quickSorter.stats() + "\n");
						if(i == testTrials) {
							quickSorter.FileWriteMCPToFile();
						}
					}
				}
				
				System.out.println("--------------------------------------------------------\nType [1] To Generate Random Points To "
						+ "Sort\nType [2] To Input A File Path\nType [3] For Both\nType [4] To Quit\n--------------------------------------------------------");
				inputAnswer = myScanner.nextInt();
			}
			
			System.out.println("Thanks For Playing :D");
		}	
		catch(FileNotFoundException e) {
			System.out.println("FileNotFoundException Error Found");
		}
		catch(InputMismatchException e) {
			System.out.println("InputMismatchException Error Found");
		}
		catch(Exception e) {
			System.out.println("Unknown Error Found");
		}
	
	}	
	
	// C:/Users/josep/OneDrive/Desktop/ComputerScience228/edu.iastate.cs228.hw2.zip_expanded/edu/iastate/cs228/hw2/myFile.txt

		/*   a) If asked to scan random points, calls generateRandomPoints() to initialize an array 
		//       of random points. 
		// 
		//    b) Reassigns to the array scanners[] (declared below) the references to four new 
		//       PointScanner objects, which are created using four different values  
		//       of the Algorithm type:  SelectionSort, InsertionSort, MergeSort and QuickSort. 
		// 
		// 	
		PointScanner[] scanners = new PointScanner[4]; 
		
		// For each input of points, do the following. 
		// 
		//     a) Initialize the array scanners[].  
		//
		//     b) Iterate through the array scanners[], and have every scanner call the scan() 
		//        method in the PointScanner class.  
		//
		//     c) After all four scans are done for the input, print out the statistics table from
		//		  section 2.
		//
		// A sample scenario is given in Section 2 of the project description. *
	
	
	/**
	 * This method generates a given number of random points.
	 * The coordinates of these points are pseudo-random numbers within the range 
	 * [-50,50] � [-50,50]. Please refer to Section 3 on how such points can be generated.
	 * 
	 * Ought to be private. Made public for testing. 
	 * 
	 * @param numPts  	number of points
	 * @param rand      Random object to allow seeding of the random number generator
	 * @throws IllegalArgumentException if numPts < 1
	 */
	public static Point[] generateRandomPoints(int numPts, Random rand) throws IllegalArgumentException
	{ 
		Point[] returnPoints = new Point[numPts];
		for(int i = 0; i < numPts; i++) {
			returnPoints[i] = new Point(rand.nextInt(101) - 50, rand.nextInt(101) - 50);
		}		

		return returnPoints;

	}
	
}
