package edu.iastate.cs228.hw2;

import java.io.FileNotFoundException;
import java.lang.NumberFormatException; 
import java.lang.IllegalArgumentException; 
import java.util.InputMismatchException;

/**
 *  
 * @author
 *
 */

/**
 * 
 * This class implements the mergesort algorithm.   
 *
 */

public class MergeSorter extends AbstractSorter
{
	// Other private instance variables if needed
	
	/** 
	 * Constructor takes an array of points.  It invokes the superclass constructor, and also 
	 * set the instance variables algorithm in the superclass.
	 *  
	 * @param pts   input array of integers
	 */
	public MergeSorter(Point[] pts) 
	{
		super(pts);
		super.algorithm = "MergeSort";

	}


	/**
	 * Perform mergesort on the array points[] of the parent class AbstractSorter. 
	 * 
	 */
	@Override 
	public void sort()
	{
		mergeSortRec(super.points); 
	}

	
	/**
	 * This is a recursive method that carries out mergesort on an array pts[] of points. One 
	 * way is to make copies of the two halves of pts[], recursively call mergeSort on them, 
	 * and merge the two sorted subarrays into pts[].   
	 * 
	 * @param pts	point array 
	 */
	private void mergeSortRec(Point[] pts)
	{
		int arrayLength = pts.length;
		if(arrayLength <= 1) {
			return;
		}
	
		int midIndex = arrayLength / 2;
		Point[] leftHalf = new Point[midIndex];
		Point[] rightHalf = new Point[arrayLength - midIndex];
		
		for(int i = 0; i < midIndex; i++) {
			leftHalf[i] = pts[i];
		}
		for(int i = midIndex; i < arrayLength; i++) {
			rightHalf[i - midIndex] = pts[i];
		}
		
		mergeSortRec(leftHalf);
		mergeSortRec(rightHalf);
		
		merge(pts, leftHalf, rightHalf);
	}
	
	// Other private methods if needed ...

	private void merge(Point[] unsortedArray, Point[] leftHalf, Point[] rightHalf) {
		int leftSize = leftHalf.length;
		int rightSize = rightHalf.length;
		
		int i = 0, j = 0, k = 0;
		
		while(i < leftSize && j < rightSize) {
			if(leftHalf[i].compareTo(rightHalf[j]) <= 0) {
				unsortedArray[k] = leftHalf[i];
				i++;
			}
			else {
				unsortedArray[k] = rightHalf[j];
				j++;
			}
			k++;
		}
		while(i < leftSize) {
			unsortedArray[k]  = leftHalf[i];
			i++;
			k++;
		}
		
		while(j < rightSize) {
			unsortedArray[k] = rightHalf[j];
			j++;
			k++;
		}
	
	}
}
