package edu.iastate.cs228.hw2;

/**
 * 
 * @author 
 *
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.InputMismatchException;


/**
 * 
 * This class sorts all the points in an array of 2D points to determine a reference point whose x and y 
 * coordinates are respectively the medians of the x and y coordinates of the original points. 
 * 
 * It records the employed sorting algorithm as well as the sorting time for comparison. 
 *
 */
public class PointScanner  
{
	private Point[] points; 
	
	private Point medianCoordinatePoint;  // point whose x and y coordinates are respectively the medians of 
	                                      // the x coordinates and y coordinates of those points in the array points[].
	private Algorithm sortingAlgorithm;    
	
	private int numPoints;
		
	protected long scanTime; 	       // execution time in nanoseconds. 
	
	/**
	 * This constructor accepts an array of points and one of the four sorting algorithms as input. Copy 
	 * the points into the array points[].
	 * 
	 * @param  pts  input array of points 
	 * @throws IllegalArgumentException if pts == null or pts.length == 0.
	 */
	public PointScanner(Point[] pts, Algorithm algo) throws IllegalArgumentException
	{
		this.sortingAlgorithm = algo;		
		this.numPoints = pts.length;
		this.points = new Point[numPoints];
		for(int i = 0; i < pts.length; i++) {
			this.points[i] = pts[i];
		}
	}

	
	/**
	 * This constructor reads points from a file. 
	 * 
	 * @param  inputFileName
	 * @throws FileNotFoundException 
	 * @throws InputMismatchException   if the input file contains an odd number of integers
	 */
	protected PointScanner(String inputFileName, Algorithm algo) throws FileNotFoundException, InputMismatchException
	{
		sortingAlgorithm = algo;
		File inputFile = new File(inputFileName);
		Scanner myScanner = new Scanner(inputFile);
		int numPoints = 0;
		int numIntegers = 0;
		while(myScanner.hasNext()) {
			myScanner.nextInt();
			numIntegers++;
		}
		if(numIntegers % 2 != 0) {
			System.out.println("Odd Number Of Integers In File");
			return;
		}
		numPoints = numIntegers / 2;
		this.numPoints = numPoints;
		myScanner.close();
		myScanner = new Scanner(inputFile);
		points = new Point[numPoints];
		int i = 0;
		while(myScanner.hasNextInt()) {
			int xCord = myScanner.nextInt();
			int yCord = myScanner.nextInt();
			Point temp = new Point(xCord, yCord);
			this.points[i] = temp;
			i++;
		}
		
	}
	
	public void printAll() {
		for(int i = 0; i < points.length; i++) {
			System.out.println("(" + points[i].getX() + ", " + points[i].getY() + ")");
		}
		System.out.println();
	}

	
	/**
	 * Carry out two rounds of sorting using the algorithm designated by sortingAlgorithm as follows:  
	 *    
	 *     a) Sort points[] by the x-coordinate to get the median x-coordinate. 
	 *     b) Sort points[] again by the y-coordinate to get the median y-coordinate.
	 *     c) Construct medianCoordinatePoint using the obtained median x- and y-coordinates.     
	 *  
	 * Based on the value of sortingAlgorithm, create an object of SelectionSorter, InsertionSorter, MergeSorter,
	 * or QuickSorter to carry out sorting.       
	 * @param algo
	 * @return
	 */
	public void scan()
	{
		AbstractSorter aSorter = null; 
		if(sortingAlgorithm == Algorithm.InsertionSort) {
			aSorter = new InsertionSorter(points);
		}
		else if(sortingAlgorithm == Algorithm.MergeSort) {
			aSorter = new MergeSorter(points);
		}
		else if(sortingAlgorithm == Algorithm.QuickSort) {
			aSorter = new QuickSorter(points);
		}
		else if(sortingAlgorithm == Algorithm.SelectionSort) {
			aSorter = new SelectionSorter(points);
		}
		
		long beforeTime = (long) System.nanoTime();
		
		aSorter.setComparator(0);
		aSorter.sort();
		int medianX = aSorter.getMedian().getX();

		aSorter.setComparator(1);
		aSorter.sort();
		int medianY = aSorter.getMedian().getY();
		
		long afterTime = (long) System.nanoTime();

		this.scanTime = afterTime - beforeTime;
		medianCoordinatePoint = new Point(medianX, medianY);
				
		// create an object to be referenced by aSorter according to sortingAlgorithm. for each of the two 
		// rounds of sorting, have aSorter do the following: 
		// 
		//     a) call setComparator() with an argument 0 or 1. 
		//
		//     b) call sort(). 		
		// 
		//     c) use a new Point object to store the coordinates of the medianCoordinatePoint
		//
		//     d) set the medianCoordinatePoint reference to the object with the correct coordinates.
		//
		//     e) sum up the times spent on the two sorting rounds and set the instance variable scanTime. 
		
	}
	
	
	/**
	 * Outputs performance statistics in the format: 
	 * 
	 * <sorting algorithm> <size>  <time>
	 * 
	 * For instance, 
	 * 
	 * selection sort   1000	  9200867
	 * 
	 * Use the spacing in the sample run in Section 2 of the project description. 
	 */
	public String stats()
	{
		String algorithmMethod = null;
		if(sortingAlgorithm == Algorithm.SelectionSort) {
			algorithmMethod = "Selectionsort";
		}
		else if(sortingAlgorithm == Algorithm.InsertionSort) {
			algorithmMethod = "InsertionSort";
		}
		else if(sortingAlgorithm == Algorithm.MergeSort) {
			algorithmMethod = "MergeSort";
		}
		else if(sortingAlgorithm == Algorithm.QuickSort) {
			algorithmMethod = "QuickSort";
		}
		String performanceStat = algorithmMethod + "  		 " + numPoints + "  		 	  " + scanTime;
		return performanceStat; 
	}
	
	
	/**
	 * Write MCP after a call to scan(),  in the format "MCP: (x, y)"   The x and y coordinates of the point are displayed on the same line with exactly one blank space 
	 * in between. 
	 */
	@Override
	public String toString()
	{
		String MCP = "MCP: (" + medianCoordinatePoint.getX() + ", " + medianCoordinatePoint.getY() + ")";
		return MCP;
	}

	
	/**
	 *  
	 * This method, called after scanning, writes point data into a file by outputFileName. The format 
	 * of data in the file is the same as printed out from toString().  The file can help you verify 
	 * the full correctness of a sorting result and debug the underlying algorithm. 
	 * 
	 * @throws FileNotFoundException
	 */
	public void FileWriteMCPToFile() throws FileNotFoundException // Writing MCP To File From Random Points Rather Than A File
	{
		try {
			FileWriter myFileWriter = new FileWriter("MPCFileHistory.txt", true);
			LocalDateTime currentDateTime = LocalDateTime.now();
			myFileWriter.write(toString() + " " + currentDateTime + " \n");
			myFileWriter.close();
		}
		catch(IOException e) {
			System.out.println("IOException Error Found");
			
			e.printStackTrace();
		}
	}	
	
	/**
	 *  
	 * This method, called after scanning, writes point data into a file by outputFileName. The format 
	 * of data in the file is the same as printed out from toString().  The file can help you verify 
	 * the full correctness of a sorting result and debug the underlying algorithm. 
	 * 
	 * @throws FileNotFoundException
	 */
	
	public void RandomWriteMCPToFile() throws FileNotFoundException // Writing MCP To File From A File Reading Rather Than Random Points
	{
		try {
			FileWriter myFileWriter = new FileWriter("MPCRandomHistory.txt", true);
			LocalDateTime currentDateTime = LocalDateTime.now();
			myFileWriter.write(toString() + " " + currentDateTime + " \n");
			myFileWriter.close();
		}
		catch(IOException e) {
			System.out.println("IOException Error Found");
			
			e.printStackTrace();
		}
	}	
	
	/**
	 *  
	 * This method, called after scanning, writes point data into a file by outputFileName. The format 
	 * of data in the file is the same as printed out from toString().  The file can help you verify 
	 * the full correctness of a sorting result and debug the underlying algorithm. 
	 * 
	 * @throws FileNotFoundException
	 */
	public void WriteMCPToFile() throws FileNotFoundException // Base Method Of The Two Other Similiar Methods
	{
		try {
			FileWriter myFileWriter = new FileWriter(sortingAlgorithm.toString() + ".txt", true);
			LocalDateTime currentDateTime = LocalDateTime.now();
			myFileWriter.write(toString() + " " + currentDateTime + " \n");
			myFileWriter.close();
		}
		catch(IOException e) {
			System.out.println("IOException Error Found");
			
			e.printStackTrace();
		}
	}	
}
