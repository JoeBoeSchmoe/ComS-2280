package edu.iastate.cs228.hw3;

/**
 * 
 *	@author: Joseph Sheets
 *	Last Edited: 11/19/24
 * 
 */

public class StoutListTest {

	public static void main(String[] args) {
		StoutList testList = new StoutList();
		testList.add('A');
		testList.add('B');
		testList.add('C');
		testList.add('D');
		testList.add('C');
		testList.add('D');		
		testList.add('E');	
		testList.remove(2);
		testList.remove(2);
		
		//Example List
		System.out.println(testList.toStringInternal() + "\n");
		
		//Example List (Add V)
		testList.add('V');
		System.out.println(testList.toStringInternal() + "\n");
		
		//Example List (Add W)
		testList.add('W');
		System.out.println(testList.toStringInternal() + "\n");
		
		testList.add(2,'X');
		System.out.println(testList.toStringInternal() + "\n");

		testList.add(2,'Y');
		System.out.println(testList.toStringInternal() + "\n");

		testList.add(2,'Z');
		System.out.println(testList.toStringInternal() + "\n");
		
		testList.remove(testList.size()-1);
		System.out.println(testList.toStringInternal() + "\n");
		
		testList.remove(3);
		System.out.println(testList.toStringInternal() + "\n");

		testList.remove(3);
		System.out.println(testList.toStringInternal() + "\n");
		
		testList.remove(5);
		System.out.println(testList.toStringInternal() + "\n");

		testList.remove(3);
		System.out.println(testList.toStringInternal() + "\n");
		
		// End Of Doc Testing

		testList.add(6,'Y'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");

		testList.add(6,'Z'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");

		testList.add(6,'H'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
		
		
		testList.add(8,'H'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
	
		testList.add(7,'M'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
	
		testList.add(7,'P'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
	
		testList.add(7,'G'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
		
		testList.add(7,'R'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
		
		System.out.println(testList.size());
		
		testList.add(13,'J'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
		
		testList.remove(3);
		System.out.println(testList.toStringInternal() + "\n");

		testList.remove(3);
		System.out.println(testList.toStringInternal() + "\n");
		
		testList.remove(3);
		System.out.println(testList.toStringInternal() + "\n");
		
		
		testList.add(13,'I'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
		
		testList.add(14,'C'); // Extra tests
		System.out.println(testList.toStringInternal() + "\n");
	}

}
