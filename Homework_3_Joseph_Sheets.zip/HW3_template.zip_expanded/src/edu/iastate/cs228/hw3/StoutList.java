package edu.iastate.cs228.hw3;

import java.util.AbstractSequentialList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * 
 *	@author: Joseph Sheets
 *	Last Edited: 11/19/24
 * 
 */

/**
 * Implementation of the list interface based on linked nodes
 * that store multiple items per node.  Rules for adding and removing
 * elements ensure that each node (except possibly the last one)
 * is at least half full.
 */
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E>
{
  /**
   * Default number of elements that may be stored in each node.
   */
  private static final int DEFAULT_NODESIZE = 4;
  
  /**
   * Number of elements that can be stored in each node.
   */
  private final int nodeSize;
  
  /**
   * Dummy node for head.  It should be private but set to public here only  
   * for grading purpose.  In practice, you should always make the head of a 
   * linked list a private instance variable.  
   */
  public Node head;
  
  /**
   * Dummy node for tail.
   */
  private Node tail;
  
  /**
   * Number of elements in the list.
   */
  private int size;
  
  private int totalAllocatedSpace;
  
  /**
   * Number Of (Nodes * 4) - 1
   */
  
  /**
   * Constructs an empty list with the default node size.
   */
  
  private Node cursorNode;
  
  private StoutListIterator theListIterator;
  public StoutList()
  {
    this(DEFAULT_NODESIZE);
    cursorNode = head;
    this.theListIterator = new StoutListIterator(0);
  }

  /**
   * Constructs an empty list with the given node size.
   * @param nodeSize number of elements that may be stored in each node, must be 
   *   an even number
   */
  public StoutList(int nodeSize)
  {
    if (nodeSize <= 0 || nodeSize % 2 != 0) {
    	throw new IllegalArgumentException();
    }
    
    // dummy nodes
    head = new Node();
    tail = new Node();
    head.next = tail;
    tail.previous = head;
    this.nodeSize = nodeSize;
    cursorNode = head;
  }
  
  /**
   * Constructor for grading only.  Fully implemented. 
   * @param head
   * @param tail
   * @param nodeSize
   * @param size
   */
  public StoutList(Node head, Node tail, int nodeSize, int size)
  {
	  this.head = head; 
	  this.tail = tail; 
	  this.nodeSize = nodeSize; 
	  this.size = size; 
	  cursorNode = head;
	 
  }

  @Override
  public int size() {
	  return size;
  }
  
  @Override
  public boolean add(E item) {
	  if(item == null) {
		  throw new NullPointerException();
	  }

	  if(cursorNode.count >= nodeSize || cursorNode == head) {
		  theListIterator.createNode(item);

	  }
	  else {
		  cursorNode.addItem(item);
	  }
	  
	  cursorNode = tail.previous;
	  //System.out.println("Current Tail First Point " + tail.previous.data[0]);
	  //System.out.println("Successfully Added " + item + " To The Node At Node Iterator " + theListIterator.findIndexFromHead(size - 1) % 4);
	  return true;
  }

  @Override
  public void add(int pos, E item)
  {
	  theListIterator.findTotalAllocatedSpace();
	  if(item == null || pos < 0 || pos > totalAllocatedSpace) {
		  throw new NullPointerException();
	  }
	  theListIterator.findCursorNodeLiteral(pos);
	  
	  if((pos % 4) > cursorNode.count) {
		  return;
	  }
	  if(cursorNode.count >= nodeSize) {
		  /*if(pos == 7) {
				System.out.println("Round One\nItem: "+ item + " Pos: " + pos);
				System.out.print("Current Node previous: "); cursorNode.previous.showString();
				System.out.print("Current Node previous next: "); cursorNode.previous.next.showString();
				System.out.print("Current Node: "); cursorNode.showString();
				System.out.print("Current Node next: "); cursorNode.next.showString();
				System.out.print("current tail previous: "); tail.previous.showString();
				System.out.println();
		  }*/
		  
		  theListIterator.createNode(item, pos);
	  }
	  else{
		  //System.out.print("current Node "); cursorNode.showString();
		  cursorNode.addItem(pos % 4, item);
		  
			/*System.out.println("Item: "+ item + " Pos: " + pos);
			System.out.print("Current Node previous: "); cursorNode.previous.showString();
			System.out.print("Current Node previous next: "); cursorNode.previous.next.showString();
			System.out.print("Current Node: "); cursorNode.showString();
			System.out.print("Current Node next: "); cursorNode.next.showString();
			System.out.print("current tail previous: "); tail.previous.showString();*/
	  }
	  cursorNode = tail.previous;
	  //System.out.println("Successfully Added " + item + " To The Node At Node Iterator " + theListIterator.findIndexFromHead(pos) % 4);
  }

  @Override
  public E remove(int pos)
  {
	  E returnData;
	  if(pos < 0 || pos >= size) {
		  throw new NullPointerException();
	  }
	  theListIterator.findCursorNode(pos);
	  returnData = cursorNode.data[theListIterator.findIndexFromHead(pos) % 4];
	  cursorNode.removeItem(theListIterator.findIndexFromHead(pos) % 4);
	  
	  if(cursorNode.next == tail) {
		  
		  if(cursorNode.count == 0) {
			  //System.out.println("Deleted Node");
			  if(cursorNode.previous == head) {
				  head.next = cursorNode.next;
				  cursorNode.next.previous = head;
			  }
			  else if(cursorNode.next == tail) {
				  tail.previous = cursorNode.previous;
				  cursorNode.previous.next = tail;
			  }
			  else {
				  cursorNode.previous.next = cursorNode.next;
				  cursorNode.next.previous = cursorNode.previous;
			  }
		  }
		 
	  }
	  else {
		  Node tempNode = new Node();
			
		  for(int i = 0; i < cursorNode.count; i ++) {
			  tempNode.data[i] = cursorNode.data[i];
			  tempNode.count++;
		  }
		  if(cursorNode.count < 2) {
			  cursorNode.addItem(cursorNode.next.data[0]);
			  cursorNode.next.removeItem(0);
			  if(cursorNode.next.count == 0) {
				  cursorNode.next = cursorNode.next.next;
			  }
		  }
		  
	  }
	  cursorNode = tail.previous;
	  return returnData;
  }

  /**
   * Sort all elements in the stout list in the NON-DECREASING order. You may do the following. 
   * Traverse the list and copy its elements into an array, deleting every visited node along 
   * the way.  Then, sort the array by calling the insertionSort() method.  (Note that sorting 
   * efficiency is not a concern for this project.)  Finally, copy all elements from the array 
   * back to the stout list, creating new nodes for storage. After sorting, all nodes but 
   * (possibly) the last one must be full of elements.  
   *  
   * Comparator<E> must have been implemented for calling insertionSort().    
   */
  public void sort()
  {
	  	E[] sortedDataList = (E[]) new Comparable[size];
	  	int tempIndex = 0;
	  	Node tempNode = head.next;
	  	while(tempNode != tail) {
	  		for(int i = 0; i < tempNode.count; i++) {
	  			sortedDataList[tempIndex] = tempNode.data[i];
	  			tempIndex++;
	  		}
	  		tempNode = tempNode.next;
	  	}
	  	
	  	head.next = tail;
	  	tail.previous = head;
	  	
	  	insertionSort(sortedDataList, new ElementComparator());
	  	size = 0;
	  	for(int i = 0; i < sortedDataList.length; i++) {
	  		add(sortedDataList[i]);
	  	}
  }
  
  /**
   * Sort all elements in the stout list in the NON-INCREASING order. Call the bubbleSort()
   * method.  After sorting, all but (possibly) the last nodes must be filled with elements.  
   *  
   * Comparable<? super E> must be implemented for calling bubbleSort(). 
   */
  public void sortReverse() 
  {
	  
	  E[] otherSortedDataList = (E[]) new Comparable[size];
	  int tempIndex = 0;
	  Node tempNode = head.next;
	  
	  while(tempNode != tail) {
		  for(int i = 0; i < tempNode.count; i++) {
			  otherSortedDataList[tempIndex] = tempNode.data[i];
			  tempIndex++;
		  }
		  tempNode = tempNode.next;
	  }
	  
	  head.next = tail;
	  tail.previous = head;
	  
	  bubbleSort(otherSortedDataList);
	  size = 0;
	  for( int i = 0; i < otherSortedDataList.length; i++) {
		  add(otherSortedDataList[i]);
	  }
  }
  
  @Override
  public Iterator<E> iterator()
  {
	  return new StoutListIterator();
  }

  @Override
  public ListIterator<E> listIterator()
  {
	  return new StoutListIterator();
   
  }

  @Override
  public ListIterator<E> listIterator(int index)
  {
	  return new StoutListIterator(index);
  }
  
  /**
   * Returns a string representation of this list showing
   * the internal structure of the nodes.
   */
  public String toStringInternal()
  {
    return toStringInternal(null);
  }

  /**
   * Returns a string representation of this list showing the internal
   * structure of the nodes and the position of the iterator.
   *
   * @param iter
   *            an iterator for this list
   */
  public String toStringInternal(ListIterator<E> iter) 
  {
      int count = 0;
      int position = -1;
      if (iter != null) {
          position = iter.nextIndex();
      }

      StringBuilder sb = new StringBuilder();
      sb.append('[');
      Node current = head.next;
      while (current != tail) {
          sb.append('(');
          E data = current.data[0];
          if (data == null) {
              sb.append("-");
          } else {
              if (position == count) {
                  sb.append("| ");
                  position = -1;
              }
              sb.append(data.toString());
              ++count;
          }

          for (int i = 1; i < nodeSize; ++i) {
             sb.append(", ");
              data = current.data[i];
              if (data == null) {
                  sb.append("-");
              } else {
                  if (position == count) {
                      sb.append("| ");
                      position = -1;
                  }
                  sb.append(data.toString());
                  ++count;

                  // iterator at end
                  if (position == size && count == size) {
                      sb.append(" |");
                      position = -1;
                  }
             }
          }
          sb.append(')');
          current = current.next;
          if (current != tail)
              sb.append(", ");
      }
      sb.append("]");
      return sb.toString();
  }


  /**
   * Node type for this list.  Each node holds a maximum
   * of nodeSize elements in an array.  Empty slots
   * are null.
   */
  
  private class Node
  {
    /**
     * Array of actual data elements.
     */
    // Unchecked warning unavoidable.
    public E[] data = (E[]) new Comparable[nodeSize];
    
    /**
     * Link to next node.
     */
    public Node next;
    
    /**
     * Link to previous node;
     */
    public Node previous;
    
    /**
     * Index of the next available offset in this node, also 
     * equal to the number of elements in this node.
     */
    public int count;

    /**
     * Adds an item to this node at the first available offset.
     * Precondition: count < nodeSize
     * @param item element to be added
     */
    void addItem(E item)
    {
      if (count >= nodeSize)
      {
        return;
      }
      
      data[count++] = item;
      ++size;
      //useful for debugging 
      //System.out.println("Current Node Count: " + count);
           //System.out.println("Added " + item.toString() + " at index " + count + " to node "  + Arrays.toString(data));
    }
  
    /**
     * Adds an item to this node at the indicated offset, shifting
     * elements to the right as necessary.
     * 
     * Precondition: count < nodeSize
     * @param offset array index at which to put the new element
     * @param item element to be added
     */
    void addItem(int offset, E item)
    {
    	//System.out.println("node size "  + nodeSize);
      if (count >= nodeSize)
      {
    	  return;
      }
      
      for (int i = count - 1; i >= offset; --i)
      {

        data[i + 1] = data[i];
      }
      ++count;
      ++size;
      data[offset] = item;
      //useful for debugging 
      //System.out.println("Current Node Count: " + count);

      //System.out.println("Added " + item.toString() + " at index " + offset + " to node: "  + Arrays.toString(data));
    }

    /**
     * Deletes an element from this node at the indicated offset, 
     * shifting elements left as necessary.
     * Precondition: 0 <= offset < count
     * @param offset
     */
    void removeItem(int offset)
    {
      E item = data[offset]; // <--- (Is This Even Needed?)
      for (int i = offset + 1; i < nodeSize; ++i)
      {
        data[i - 1] = data[i];
      }
      data[count - 1] = null;
      --count;
      --size;
      //System.out.println("Removed " + item.toString() + " at index " + offset + " to node: "  + Arrays.toString(data));

    }
    void showString() {
		System.out.print("( ");
    	for(int i = 0; i < 4; i ++) {
    		if(i < count) {
        		System.out.print(data[i]+ ", ");
    		}
    		else {
    			System.out.print("- ");
    		}
    	}
		System.out.println(")");
    }

  }
  
  private class StoutListIterator implements ListIterator<E>
  {
	// constants you possibly use ...   
	  
	// instance variables ... 
	  
	  int indexFromHead;
	  int currentIndex;
	  
    /**
     * Default constructor 
     */
    public StoutListIterator()
    {
    	this.indexFromHead = 0;
    	this.currentIndex = 0;
    }

    /**
     * Constructor finds node at a given position.
     * @param pos
     */
    public StoutListIterator(int pos) {
	    if(pos < 0 || pos > size) {
	    	throw new NullPointerException();
	    }
    	this.indexFromHead = 0;
	    this.currentIndex  = pos;
    }

    @Override
    public boolean hasNext()
    {
    	if(currentIndex < size - 1) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
    
    public void changeIndexFromHead(int index) {
    	indexFromHead = index;
    }

    @Override
    public E next()
    {
    	if(hasNext() == false) {
    		throw new NullPointerException();
    	}
    	cursorNode = head.next;
    	int nodeIterator = 0;
    	int indexFromHead = 0;
    	int valuesFound = 0;
  	  
    	while(valuesFound <= currentIndex + 1) {
    		if(nodeIterator == 4) {
    			if(cursorNode.next != null) {
    				cursorNode = cursorNode.next;
  		  		}
  		  		nodeIterator = 0;
  		  	}

  		  	if(cursorNode.data[nodeIterator] != null) {
  		  		//System.out.println("Position " + valuesFound + " Found At Index: " + indexFromHead + " | With Value: " + cursorNode.data[nodeIterator]);
  		  		valuesFound++;

  		  	}

  		  	nodeIterator++;
  		  	indexFromHead++;

  	  }
  	  	indexFromHead--;
  	  	
  	  	currentIndex = currentIndex + 1;
  	  	return cursorNode.data[indexFromHead % 4];

    }

    @Override
    public void remove()
    {
    	cursorNode = head.next;
    	int nodeIterator = 0;
    	int indexFromHead = 0;
    	int valuesFound = 0;
  	  
    	while(valuesFound <= currentIndex) {
    		if(nodeIterator == 4) {
    			if(cursorNode.next != null) {
    				cursorNode = cursorNode.next;
  		  		}
  		  		nodeIterator = 0;
  		  	}

  		  	if(cursorNode.data[nodeIterator] != null) {
  		  		//System.out.println("Position " + valuesFound + " Found At Index: " + indexFromHead + " | With Value: " + cursorNode.data[nodeIterator]);
  		  		valuesFound++;

  		  	}

  		  	nodeIterator++;
  		  	indexFromHead++;

  	  }
  	  	indexFromHead--;
  	  	
  	  	if(currentIndex != 0) {
  	  	currentIndex = currentIndex - 1;
  	  	}
  	  	cursorNode.removeItem(nodeIterator);
    }

	@Override
	public boolean hasPrevious() {
		if(currentIndex == 0) {
			return false;
		}
		else {
			return true;
		}
	}

	@Override
	public E previous() {
    	if(hasPrevious() == false) {
    		return null;
    	}
    	cursorNode = head.next;
    	int nodeIterator = 0;
    	int indexFromHead = 0;
    	int valuesFound = 0;
  	  
    	while(valuesFound <= currentIndex - 1) {
    		if(nodeIterator == 4) {
    			if(cursorNode.next != null) {
    				cursorNode = cursorNode.next;
  		  		}
  		  		nodeIterator = 0;
  		  	}

  		  	if(cursorNode.data[nodeIterator] != null) {
  		  		//System.out.println("Position " + valuesFound + " Found At Index: " + indexFromHead + " | With Value: " + cursorNode.data[nodeIterator]);
  		  		valuesFound++;

  		  	}

  		  	nodeIterator++;
  		  	indexFromHead++;
  		  	
  	  }
  	  	indexFromHead--;
  	  	
  	  	return cursorNode.data[indexFromHead % 4];
	}

	@Override
	public int nextIndex() {
		if(hasNext() == false) {
			throw new NullPointerException();
		}
		return currentIndex + 1;
	}

	@Override
	public int previousIndex() {
		if(hasPrevious() == false) {
			throw new NullPointerException();
		}
		return currentIndex - 1;
	}

	
	@Override
	public void set(E e) {
		if(e == null) {
			throw new NullPointerException();
		}
		findCursorNode(currentIndex);
		cursorNode.data[findIndexFromHead(currentIndex) % 4]  = e;
		
		changeIndexFromHead(size - 1);
	}

	@Override
	public void add(E e) {
		if(e == null) {
			throw new NullPointerException();
		}
		findCursorNode(currentIndex);
		
		if(cursorNode.count >= 4) {
			createNode(e, currentIndex);
		}
		else {
			cursorNode.addItem(e);
		}
		currentIndex++;
	}
    
    // Other methods you may want to add or override that could possibly facilitate 
    // other operations, for instance, addition, access to the previous element, etc.
    // 
    // ...
    // 
	
	public E current() {
    	cursorNode = head.next;
    	int nodeIterator = 0;
    	int indexFromHead = 0;
    	int valuesFound = 0;
  	  
    	while(valuesFound <= currentIndex) {
    		if(nodeIterator == 4) {
    			if(cursorNode.next != null) {
    				cursorNode = cursorNode.next;
  		  		}
  		  		nodeIterator = 0;
  		  	}

  		  	if(cursorNode.data[nodeIterator] != null) {
  		  		//System.out.println("Position " + valuesFound + " Found At Index: " + indexFromHead + " | With Value: " + cursorNode.data[nodeIterator]);
  		  		valuesFound++;

  		  	}

  		  	nodeIterator++;
  		  	indexFromHead++;

  	  }
  	  	indexFromHead--;
  	  	
  	  	return cursorNode.data[indexFromHead % 4];
	}
	public void findTotalAllocatedSpace() {
		cursorNode = head.next;
    	totalAllocatedSpace = 0;
    	int numNodes = 0;
    	while(cursorNode.next != null) {
    		cursorNode = cursorNode.next;
    		numNodes++;
    	}
    	totalAllocatedSpace = (numNodes * 4) - 1;
    	//System.out.println(totalAllocatedSpace);
	}
	public void findCursorNodeLiteral(int pos) {
		cursorNode = head.next;
    	int nodeIterator = 1;
		for(int i = 1; i <= pos; i++) {
			if(nodeIterator == 4) {
				nodeIterator = 0;
				cursorNode = cursorNode.next;
			}
			nodeIterator++;

			//System.out.print(pos); cursorNode.showString();

		}	
	}
	public void findCursorNode(int currentIndex) {
		cursorNode = head.next;
    	int nodeIterator = 0;
    	int valuesFound = 0;
  	  
    	while(valuesFound <= currentIndex) {
    		if(nodeIterator == 4) {
    			if(cursorNode.next != null) {
    				cursorNode = cursorNode.next;
  		  		}
  		  		nodeIterator = 0;
  		  	}

  		  	if(cursorNode.data[nodeIterator] != null) {
  		  		//System.out.println("Position " + valuesFound + " Found At Index: " + indexFromHead + " | With Value: " + cursorNode.data[nodeIterator]);
  		  		valuesFound++;
  		  	}
  		  	nodeIterator++;
  	  }
	}
	
	public int findIndexFromHead(int pos) {
		if(pos < 0 || pos >= size) {
			  throw new NullPointerException();
		  }
		  
		  cursorNode = head.next;
		  int nodeIterator = 0;
		  int indexFromHead = 0;
		  int valuesFound = 0;
		  
		  while(valuesFound <= pos) {
			  if(nodeIterator == 4) {
				  if(cursorNode.next != null) {
					  cursorNode = cursorNode.next;
				  }
				  nodeIterator = 0;
			  }
			  
			  if(cursorNode.data[nodeIterator] != null) {
				  //System.out.println("Position " + valuesFound + " Found At Index: " + indexFromHead + " | With Value: " + cursorNode.data[nodeIterator]);
				  valuesFound++;
				  
			  }
			  nodeIterator++;
			  indexFromHead++;

		  }
		  nodeIterator--;
		  indexFromHead--;
		  return indexFromHead;
	}
	
	public void createNode(E item) { // Creating New Node To Make Up Space (No Position Given)
		Node nextNewNode = new Node();
		if (cursorNode.next == tail) {
			nextNewNode.addItem(item);
			nextNewNode.previous = cursorNode;
			nextNewNode.next = tail;
			cursorNode.next = nextNewNode;
			tail.previous = nextNewNode;
		}
		else if(cursorNode.count >= 4) {
			nextNewNode.addItem(item);
			nextNewNode.previous = cursorNode;
			nextNewNode.next = cursorNode.next;
			cursorNode.next = nextNewNode;
			cursorNode.next.previous = nextNewNode;
		}
		
	}
	public void createNode(E item, int pos) { // Creating New Node To Make Up Space (Position Given)
		E tempVal;

		Node nextNewNode = new Node();
		
		if(cursorNode.next == tail) {
			nextNewNode.addItem(cursorNode.data[2]);
			nextNewNode.addItem(cursorNode.data[3]);
			cursorNode.data[2] = item;
			cursorNode.removeItem(3);
		}
		else {
			if(cursorNode.next.count >= 4 || cursorNode.next != tail) {				
				int nodeIterator = pos % 4;
				tempVal = cursorNode.data[nodeIterator];
				cursorNode.removeItem(nodeIterator);
				if(nodeIterator <= 1) {
					
					nextNewNode.addItem(cursorNode.data[1]);
					nextNewNode.addItem(cursorNode.data[2]);
					nextNewNode.count = 2;
					cursorNode.removeItem(3);
					cursorNode.removeItem(2);
					cursorNode.addItem(nodeIterator,item);
					cursorNode.addItem(nodeIterator+1, tempVal);
				}
				else if (nodeIterator == 2) {
					
					nextNewNode.addItem(tempVal);
					nextNewNode.addItem(cursorNode.data[2]);
					cursorNode.addItem(item);
					cursorNode.removeItem(nodeIterator);
					
				}
				else {
					nextNewNode.addItem(item);
					nextNewNode.addItem(tempVal);
				}			
			}
			else {
				
				cursorNode.addItem(pos % 4, item);				
			}
		}
		nextNewNode.next = cursorNode.next;
		nextNewNode.previous = cursorNode;
		cursorNode.next.previous = nextNewNode;
		cursorNode.next = nextNewNode;
		
		
		/*System.out.println("Item: "+ item + " Pos: " + pos);
		System.out.print("Current Node previous: "); cursorNode.previous.showString();
		System.out.print("Current Node previous next: "); cursorNode.previous.next.showString();
		System.out.print("Current Node: "); cursorNode.showString();
		System.out.print("NewNewNode: "); nextNewNode.showString();
		System.out.print("Current Node next: "); cursorNode.next.showString();
		System.out.print("current tail previous: "); tail.previous.showString();*/
		
		cursorNode = nextNewNode;
		
	}

  }
  

  /**
   * Sort an array arr[] using the insertion sort algorithm in the NON-DECREASING order. 
   * @param arr   array storing elements from the list 
   * @param comp  comparator used in sorting 
   */
  private void insertionSort(E[] arr, Comparator<? super E> comp)
  {
	  for(int i = 1; i < arr.length; i++) {
		  E tempVal = arr[i];
		  int j = i - 1;
		  while(j >= 0 && comp.compare(arr[j], tempVal) > 0) {
			  arr[j+1] = arr[j];
			  j--;
		  }
		  arr[j+1] = tempVal;
	  }
  }
  
  /**
   * Sort arr[] using the bubble sort algorithm in the NON-INCREASING order. For a 
   * description of bubble sort please refer to Section 6.1 in the project description. 
   * You must use the compareTo() method from an implementation of the Comparable 
   * interface by the class E or ? super E. 
   * @param arr  array holding elements from the list
   */
  private void bubbleSort(E[] arr)
  {
	  int length = arr.length;
	  for(int i = 0; i < length - 1; i++) {
		  for(int j = 0; j < length -1; j++) {
			  E tempVal = arr[j];
			  arr[j] = arr[j+1];
			  arr[j+1] = tempVal;
		  }
	  }
  }
  
  private class ElementComparator<E extends Comparable<E>> implements Comparator<E> {
		@Override
		public int compare(E valA, E valB) {
			return valA.compareTo(valB);
		}
	}
  

}