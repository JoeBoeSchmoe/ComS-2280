import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 
 * Author: Joseph Sheets
 * Last Edited: 04/30/24
 * 
 */

public class MsgTreeMain {

	public static void main(String[] args) throws IOException {
		
		System.out.print("please Enter Filename To Decode: ");
		Scanner myScanner = new Scanner(System.in);
		String inputFileName = myScanner.nextLine();
		myScanner.close();
		
		String fileContent = new String(Files.readAllBytes(Paths.get(inputFileName))).trim();
		int myPosition = fileContent.lastIndexOf('\n');
		String thePattern = fileContent.substring(0, myPosition);
		String theBinary = fileContent.substring(myPosition).trim();
		
		Set<Character> chars = new HashSet<>();
		char[] patternChars = thePattern.toCharArray();
		
		for(int i = 0; i < patternChars.length; i++) {
			char tempChar = patternChars[i];
			if(tempChar != '^') {
				chars.add(tempChar);
			}
		}
		String treeCode = chars.stream().map(String::valueOf).collect(Collectors.joining());
		
		MsgTree root = new MsgTree(thePattern);
		MsgTree.printCodes(root, treeCode);
		root.decode(root,theBinary);

		// C:/Users/josep/Downloads/HW4_Test_Files/cadbard.arch
		// C:/Users/josep/Downloads/HW4_Test_Files/monalisa.arch
		// C:/Users/josep/Downloads/HW4_Test_Files/twocities.arch
		// C:/Users/josep/Downloads/HW4_Test_Files/constitution.arch
	}

}
