import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

/**
 * Author:  Joseph Sheets
 * Last Edited: 04/30/24
 */
public class MsgTree {
	public char payloadChar;
	public MsgTree left;
	public MsgTree right;
	
	/**
	 * Constructor To Build The Free From A String
	 * @param fileInputName
	 */
	public MsgTree(String fileInputName) {
		if(fileInputName == null || fileInputName.length() < 2) {
			return;
		}
		
		Stack<MsgTree> stack = new Stack<>();
		this.payloadChar = fileInputName.charAt(0);
		
		MsgTree current = this;
		stack.push(current);
		boolean isLeft = true;
		
		for(int i = 1; i < fileInputName.length(); i++) {
			MsgTree newNode = new MsgTree(fileInputName.charAt(i));
			if(isLeft) {
				current.left = newNode;
			}
			else {
				current.right = newNode;
			}
			if(newNode.payloadChar == '^') {
				current = stack.push(newNode);
				isLeft = true;
			}
			else {
				if(stack.empty() == false) {
					current = stack.pop();
				}
				isLeft = false;
			}
		}
	}
	
	/**
	 * Constructor For A Single Node With No Children
	 * @param currentPayloadChar
	 */
	public MsgTree(char currentPayloadChar) {
		this.payloadChar = currentPayloadChar;
		this.left = null;
		this.right = null;
	}
	
	/**
	 * Print Characters And Their Binary Codes 
	 * @param theRoot
	 * @param treeCode
	 */
	public static void printCodes(MsgTree root, String code) {
		System.out.println("\nCharacter Codes");
		System.out.println("----------------------------------------------");
		
		Map<Character, String> charToCode = new HashMap<>();
		charToCode(root, "", charToCode);
		
		for(char c: code.toCharArray()) {
			String binary = charToCode.get(c);
			String result;
			if(c == '\n') {
				result = "\\n";
			}
			else {
				result = c + " ";
			}
			System.out.println("     " + result + "     " + binary);
		}
	}
	
	/**
	 * Use Map To Connect Each Character With A Binary Code
	 * @param theNode
	 * @param thePath
	 * @param map
	 */
	public static void charToCode(MsgTree node, String path, Map<Character, String> map) {
		if(node == null) {
			return;
		}
		if(node.payloadChar != '^') {
			map.put(node.payloadChar, path);
		}
		charToCode(node.left, path + "0", map);
		charToCode(node.right, path + "1", map);
	}
	
	/**
	 * Decodes Message Using The Alphabet Code
	 * @param theCodes
	 * @param theMessage
	 */
	public void decode(MsgTree theCodes, String theMessage) {
		System.out.println("\nDecoded Message: ");
		Map<String, Character> binaryToChar = new HashMap<>();
		codeToChar(theCodes, "", binaryToChar);
		
		StringBuilder sb = new StringBuilder();
		StringBuilder binary = new StringBuilder();
		
		char[] msgArray = theMessage.toCharArray();
		for(int i = 0; i < theMessage.length(); i++) {
			binary.append(msgArray[i]);
			Character tempChar = binaryToChar.get(binary.toString());
			if(tempChar != null) {
				sb.append(tempChar);
				binary.setLength(0);
			}
		}
		System.out.println(sb.toString() );
		System.out.println();
		printStatistics(theMessage, sb.toString());
	}
	
	/**
	 * Builds A TreeCode To Character Map
	 * @param myNode
	 * @param thePath
	 * @param theMap
	 */
	private static void codeToChar(MsgTree myNode, String thePath, Map<String, Character> theMap) {
		if(myNode == null) {
			return;
		}
		if(myNode.payloadChar != '^') {
			theMap.put(thePath, myNode.payloadChar);
		}
		codeToChar(myNode.left, thePath + "0", theMap);
		codeToChar(myNode.right, thePath + "1", theMap);
	}
	/**
	 * Extra Credit Portion
	 */
	private void printStatistics(String finalMessage, String decodedMessage) {
		System.out.println("Statistics: ");
		
		double averageBitsPerChar = calculateAverageBitsPerChar(finalMessage, decodedMessage);
		System.out.println(String.format("Average Bits/Chars: \t%.1f", averageBitsPerChar));
		int totalCharacters = decodedMessage.length();
		System.out.println(String.format("Total Characters: \t" + totalCharacters));
		
		double spaceSaving = calculateSpaceSaving(finalMessage, decodedMessage);
		System.out.println(String.format("Space Saving: \t\t%.1f%%", spaceSaving));
	}
	
	private double calculateAverageBitsPerChar(String finalMessage, String decodedMessage) {
		return finalMessage.length() / (double) decodedMessage.length();
	}
	private double calculateSpaceSaving(String finalMessage, String decodedMessage) {
		return (1d - decodedMessage.length() / (double) finalMessage.length()) * 100;
	}
}
